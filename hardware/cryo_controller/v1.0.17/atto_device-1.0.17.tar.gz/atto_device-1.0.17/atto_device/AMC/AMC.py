from . import ACS
from .rotcomp import Rotcomp
from .network import Network
from .move import Move
from .diagnostic import Diagnostic
from .test import Test
from .amcids import Amcids
from .system_service import System_service
from .update import Update
from .about import About
from .access import Access
from .res import Res
from .rtin import Rtin
from .rtout import Rtout
from .status import Status
from .description import Description
from .control import Control


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.rotcomp = Rotcomp(self)
        self.network = Network(self)
        self.move = Move(self)
        self.diagnostic = Diagnostic(self)
        self.test = Test(self)
        self.amcids = Amcids(self)
        self.system_service = System_service(self)
        self.update = Update(self)
        self.about = About(self)
        self.access = Access(self)
        self.res = Res(self)
        self.rtin = Rtin(self)
        self.rtout = Rtout(self)
        self.status = Status(self)
        self.description = Description(self)
        self.control = Control(self)
        
        

def discover():
    return Device.discover("amc")
