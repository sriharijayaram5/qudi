class Functions:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.amc.functions"

    def apply(self, key):
        # type: (int) -> ()
        """
        Apply temporary system configuration

        Parameters:
            key: 
                    
        """
        
        response = self.device.request(self.interface_name + ".apply", [key, ])
        self.device.handleError(response)
        return                 

