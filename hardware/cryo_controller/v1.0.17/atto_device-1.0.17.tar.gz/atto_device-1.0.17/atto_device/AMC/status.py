class Status:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.amc.status"

    def getStatusConnected(self, axis):
        # type: (int) -> (bool)
        """
        This function gets information about the connection status of the selected axis’ positioner.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_connected: connected If true, the actor is connected
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusConnected", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusReference(self, axis):
        # type: (int) -> (bool)
        """
        This function gets information about the status of the reference position.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_valid: valid true = valid, false = not valid
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusReference", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusMoving(self, axis):
        # type: (int) -> (int)
        """
        This function gets information about the status of the stage output.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_status: status 0: Idle, i.e. within the noise range of the sensor, 1: Moving, i.e the actor is actively driven by the output stage either for closed-loop approach or continous/single stepping and the output is active.
  2 : Pending means the output stage is driving but the output is deactivated
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusMoving", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusEotFwd(self, axis):
        # type: (int) -> (bool)
        """
        This function gets the status of the end of travel detection on the selected axis in forward direction.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_detected: detected true when EoT was detected
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusEotFwd", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusEotBkwd(self, axis):
        # type: (int) -> (bool)
        """
        This function gets the status of the end of travel detection on the selected axis in backward direction.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_detected: detected true when EoT was detected
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusEotBkwd", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusEot(self, axis):
        # type: (int) -> (bool)
        """
        Retrieves the status of the end of travel (EOT) detection in backward direction or in forward direction.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_detected: detected true when EoT in either direction was detected
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusEot", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusTargetRange(self, axis):
        # type: (int) -> (bool)
        """
        This function gets information about whether the selected axis’ positioner is in target range or not.

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_in_range: in_range true within the target range, false not within the target range
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusTargetRange", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getOlStatus(self, axis):
        # type: (int) -> (int)
        """
        Get the Feedback status of the positioner

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_sensorstatus: sensorstatus as integer 0: NUM Positioner connected 1: OL positioner connected  2: No positioner connected , 3: RES positione connected, 4: Positioner with IDS-CL connected
                    
        """
        
        response = self.device.request(self.interface_name + ".getOlStatus", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getFullCombinedStatus(self, axis):
        # type: (int) -> (str)
        """
        Get the full combined status of a positioner axis and return the status as a string (to be used in the Webapplication)

        Parameters:
            axis: [0|1|2]
                    
        Returns:
            errNo: errNo
            value_string: string can be "moving","in target range", "backward limit reached", "forward limit reached", "positioner not connected", "grounded" (only AMC300), "output not enabled"
                    
        """
        
        response = self.device.request(self.interface_name + ".getFullCombinedStatus", [axis, ])
        self.device.handleError(response)
        return response[1]                

    def getStatusFlagsAllAxis(self):
        # type: () -> (int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int)
        """
        This function returns several status flags of all three axes
        Returns:
            err: err
            value_pos_con_axtypebool1: pos_con_ax1[type=bool] positioner connected axis 1
            value_enbld_axtypebool1: enbld_ax1[type=bool] Axis 1 enabled
            value_moving_axtypebool1: moving_ax1[type=bool] axis 1 moving
            value_in_trgt_axtypebool1: in_trgt_ax1[type=bool] axis 1 in target range
            value_eot_fwd_axtypebool1: eot_fwd_ax1[type=bool] axis 1 eot fwd flag
            value_eot_bwd_axtypebool1: eot_bwd_ax1[type=bool] axis 1 eot bwd flag
            value_gnd_axtypebool1: gnd_ax1[type=bool] axis 1 grounded (e.g. ground on target)
            value_pos_con_axtypebool2: pos_con_ax2[type=bool] positioner connected axis 2
            value_enbld_axtypebool2: enbld_ax2[type=bool] Axis 2 enabled
            value_moving_axtypebool2: moving_ax2[type=bool] axis 2 moving
            value_in_trgt_axtypebool2: in_trgt_ax2[type=bool] axis 2 in target range
            value_eot_fwd_axtypebool2: eot_fwd_ax2[type=bool] axis 2 eot fwd flag
            value_eot_bwd_axtypebool2: eot_bwd_ax2[type=bool] axis 2 eot bwd flag
            value_gnd_axtypebool2: gnd_ax2[type=bool] axis 2 grounded (e.g. ground on target)
            value_pos_con_axtypebool3: pos_con_ax3[type=bool] positioner connected axis 3
            value_enbld_axtypebool3: enbld_ax3[type=bool] Axis 3 enabled
            value_moving_axtypebool3: moving_ax3[type=bool] axis 3 moving
            value_in_trgt_axtypebool3: in_trgt_ax3[type=bool] axis 3 in target range
            value_eot_fwd_axtypebool3: eot_fwd_ax3[type=bool] axis 3 eot fwd flag
            value_eot_bwd_axtypebool3: eot_bwd_ax3[type=bool] axis 3 eot bwd flag
            value_gnd_axtypebool3: gnd_ax3[type=bool] axis 3 grounded (e.g. ground on target)
                    
        """
        
        response = self.device.request(self.interface_name + ".getStatusFlagsAllAxis")
        self.device.handleError(response)
        return response[1], response[2], response[3], response[4], response[5], response[6], response[7], response[8], response[9], response[10], response[11], response[12], response[13], response[14], response[15], response[16], response[17], response[18], response[19], response[20], response[21]                

