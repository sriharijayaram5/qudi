from . import ACS
from .system_service import System_service
from .system import System
from .update import Update
from .about import About
from .network import Network
from .tboard import Tboard
from .valves import Valves
from .membranePump import Membranepump
from .heater import Heater
from .access import Access
from .main import Main
from .scrollPump import Scrollpump
from .compressor import Compressor
from .pressures import Pressures
from .turboPump import Turbopump


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.system_service = System_service(self)
        self.system = System(self)
        self.update = Update(self)
        self.about = About(self)
        self.network = Network(self)
        self.tboard = Tboard(self)
        self.valves = Valves(self)
        self.membranePump = Membranepump(self)
        self.heater = Heater(self)
        self.access = Access(self)
        self.main = Main(self)
        self.scrollPump = Scrollpump(self)
        self.compressor = Compressor(self)
        self.pressures = Pressures(self)
        self.turboPump = Turbopump(self)
        
        

def discover():
    return Device.discover("attodryevu")
