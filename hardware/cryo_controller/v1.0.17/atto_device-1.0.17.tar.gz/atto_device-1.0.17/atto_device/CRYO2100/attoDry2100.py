from . import ACS
from .sample import Sample
from .access import Access
from .magnet import Magnet
from .action import Action
from .cryoOutValve import Cryooutvalve
from .scrollPump import Scrollpump
from .vti import Vti
from .system import System
from .tboard import Tboard
from .update import Update
from .dumpInValve import Dumpinvalve
from .stage40k import Stage40k
from .main import Main
from .system_service import System_service
from .dumpOutValve import Dumpoutvalve
from .about import About
from .network import Network
from .condenser import Condenser
from .cryoInValve import Cryoinvalve
from .pressures import Pressures


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.sample = Sample(self)
        self.access = Access(self)
        self.magnet = Magnet(self)
        self.action = Action(self)
        self.cryoOutValve = Cryooutvalve(self)
        self.scrollPump = Scrollpump(self)
        self.vti = Vti(self)
        self.system = System(self)
        self.tboard = Tboard(self)
        self.update = Update(self)
        self.dumpInValve = Dumpinvalve(self)
        self.stage40k = Stage40k(self)
        self.main = Main(self)
        self.system_service = System_service(self)
        self.dumpOutValve = Dumpoutvalve(self)
        self.about = About(self)
        self.network = Network(self)
        self.condenser = Condenser(self)
        self.cryoInValve = Cryoinvalve(self)
        self.pressures = Pressures(self)
        
        

def discover():
    return Device.discover("attodry2100")
