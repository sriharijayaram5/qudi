class Axis:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.ids.axis"

    def getPassMode(self):
        # type: () -> (int)
        """
        Reads out the current pass mode.
        Returns:
            errNo: errNo
            value_mode: mode 0 = single; pass 1 = dual pass
                    
        """
        
        response = self.device.request(self.interface_name + ".getPassMode")
        self.device.handleError(response)
        return response[1]                

    def setPassMode(self, mode):
        # type: (int) -> ()
        """
        Sets the desired pass mode.

        Parameters:
            mode: 0 = single pass; 1 = dual pass
                    
        """
        
        response = self.device.request(self.interface_name + ".setPassMode", [mode, ])
        if response[0] == 0:
            self.apply()
        else:
            self.discard()
        self.device.handleError(response)
        return                 

    def getMasterAxis(self):
        # type: () -> (int)
        """
        Returns the master axis (for more information please refer to the IDS User Manual).
        Returns:
            errNo: errNo
            value_masteraxis: masteraxis Axis which is operating as masteraxis [0..2]
                    
        """
        
        response = self.device.request(self.interface_name + ".getMasterAxis")
        self.device.handleError(response)
        return response[1]                

    def setMasterAxis(self, axis):
        # type: (int) -> ()
        """
        Sets the master axis (for more information please refer to the IDS User Manual).

        Parameters:
            axis: Axis which is operating as masteraxis [0..2]
                    
        """
        
        response = self.device.request(self.interface_name + ".setMasterAxis", [axis, ])
        if response[0] == 0:
            self.apply()
        else:
            self.discard()
        self.device.handleError(response)
        return                 

    def apply(self):
        # type: () -> ()
        """
        Applies new axis settings.
        """
        
        response = self.device.request(self.interface_name + ".apply")
        self.device.handleError(response)
        return                 

    def setAutoMasterAxis(self, is_automatic):
        # type: (int) -> ()
        """
        Enables the automatic configuration of the master Axis while initializing.

        Parameters:
            is_automatic: 1 for automatic, 0 for manual
                    
        """
        
        response = self.device.request(self.interface_name + ".setAutoMasterAxis", [is_automatic, ])
        self.device.handleError(response)
        return                 

    def getAutoMasterAxis(self):
        # type: () -> (int)
        """
        Get status of the automatic configuration of the master Axis.
        Returns:
            errNo: errNo
            is_automatic: is_automatic
                    
        """
        
        response = self.device.request(self.interface_name + ".getAutoMasterAxis")
        self.device.handleError(response)
        return response[1]                

    def setAxesDebug(self, enabled_axis1, enabled_axis2, enabled_axis3, master_axis):
        # type: (int, int, int, int) -> ()
        """
        Set axes for debugging.

        Parameters:
            enabled_axis1: true for enabled, false for disabled
            enabled_axis2: true for enabled, false for disabled
            enabled_axis3: true for enabled, false for disabled
            master_axis: -1 for automatic, 1,2 or 3 for the axes
                    
        """
        
        response = self.device.request(self.interface_name + ".setAxesDebug", [enabled_axis1, enabled_axis2, enabled_axis3, master_axis, ])
        self.device.handleError(response)
        return                 

    def getAxesDebug(self):
        # type: () -> (int, int, int)
        """
        Get axes status for debugging.
        Returns:
            errNo: errNo
            value_enabledAxes1: enabledAxes1 true for enabled, false for disabled
            value_enabledAxes2: enabledAxes2 true for enabled, false for disabled
            value_enabledAxes3: enabledAxes3 true for enabled, false for disabled
                    
        """
        
        response = self.device.request(self.interface_name + ".getAxesDebug")
        self.device.handleError(response)
        return response[1], response[2], response[3]                

    def discard(self):
        # type: () -> ()
        """
        Discards new axis settings.
        """
        
        response = self.device.request(self.interface_name + ".discard")
        self.device.handleError(response)
        return                 

