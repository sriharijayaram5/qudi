from . import ACS
from .ecu import Ecu
from .update import Update
from .system_service import System_service
from .displacement import Displacement
from .about import About
from .manual import Manual
from .axis import Axis
from .distance_absolute import Distance_absolute
from .network import Network
from .access import Access
from .nlc import Nlc
from .realtime import Realtime
from .system import System
from .functions import Functions
from .aim_calibrate import Aim_calibrate
from .pilotlaser import Pilotlaser
from .adjustment import Adjustment
try:
    from .streaming.streaming import Streaming
except:
    pass


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.ecu = Ecu(self)
        self.update = Update(self)
        self.system_service = System_service(self)
        self.displacement = Displacement(self)
        self.about = About(self)
        self.manual = Manual(self)
        self.axis = Axis(self)
        self.distance_absolute = Distance_absolute(self)
        self.network = Network(self)
        self.access = Access(self)
        self.nlc = Nlc(self)
        self.realtime = Realtime(self)
        self.system = System(self)
        self.functions = Functions(self)
        self.aim_calibrate = Aim_calibrate(self)
        self.pilotlaser = Pilotlaser(self)
        self.adjustment = Adjustment(self)
        
        try:
            self.streaming = Streaming(self)
        except NameError as e:
            if "Streaming" in str(e):
                print("Warning: Streaming is not supported on your platform")
            else:
                raise e
        

def discover():
    return Device.discover("ids")
