class Aim_calibrate:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.ids.aim_calibrate"

    def startCalibration(self):
        # type: () -> ()
        """
        Starts calibration system state.
        """
        
        response = self.device.request(self.interface_name + ".startCalibration")
        self.device.handleError(response)
        return                 

    def checkCalibration(self):
        # type: () -> ()
        """
        Checks linearized ramps with current ramp table.
        """
        
        response = self.device.request(self.interface_name + ".checkCalibration")
        self.device.handleError(response)
        return                 

    def getCalibrationStatus(self):
        # type: () -> (int)
        """
        Informs about finished startCalibration and checkCalibration.
        Returns:
            value_errNo: errNo Error during reading calibration status
            value_isValid: isValid Returns true if calibration is fine, else false
                    
        """
        
        response = self.device.request(self.interface_name + ".getCalibrationStatus")
        self.device.handleError(response)
        return response[1]                

