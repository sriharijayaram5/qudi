class Distance_absolute:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.ids.distance_absolute"

    def setNumberOfRamps(self, numberOfRamps):
        # type: (int) -> ()
        """
        Set the total number of ramps driven while ramping

        Parameters:
            numberOfRamps: Number of ramps driven while ramping
                    
        """
        
        response = self.device.request(self.interface_name + ".setNumberOfRamps", [numberOfRamps, ])
        self.device.handleError(response)
        return                 

    def setFirstNumberOfRampsToSkip(self, numberOfRamps):
        # type: (int) -> ()
        """
        Set the number of ramps to skip from start to end

        Parameters:
            numberOfRamps: Number of ramps to skip
                    
        """
        
        response = self.device.request(self.interface_name + ".setFirstNumberOfRampsToSkip", [numberOfRamps, ])
        self.device.handleError(response)
        return                 

    def getNumberOfRamps(self):
        # type: () -> (int)
        """
        Get the total number of ramps driven while ramping
        Returns:
            errNo: errNo
            value_Number: Number of ramps driven while ramping
                    
        """
        
        response = self.device.request(self.interface_name + ".getNumberOfRamps")
        self.device.handleError(response)
        return response[1]                

    def getFirstNumberOfRampsToSkip(self):
        # type: () -> (int)
        """
        Get the number of ramps to skip from start to end
        Returns:
            errNo: errNo
            value_numberOfRamps: numberOfRamps Number of ramps to skip
                    
        """
        
        response = self.device.request(self.interface_name + ".getFirstNumberOfRampsToSkip")
        self.device.handleError(response)
        return response[1]                

    def activateRounding(self, is_active):
        # type: (int) -> ()
        """
        Activate Rounding at absolute measurement,

        Parameters:
            is_active: true for active, false for inactive
                    
        """
        
        response = self.device.request(self.interface_name + ".activateRounding", [is_active, ])
        self.device.handleError(response)
        return                 

    def activateKeepRamping(self):
        # type: () -> ()
        """
        Activates keepRamping
        """
        
        response = self.device.request(self.interface_name + ".activateKeepRamping")
        self.device.handleError(response)
        return                 

    def deactivateKeepRamping(self):
        # type: () -> ()
        """
        Deactivates keepRamping
        """
        
        response = self.device.request(self.interface_name + ".deactivateKeepRamping")
        self.device.handleError(response)
        return                 

