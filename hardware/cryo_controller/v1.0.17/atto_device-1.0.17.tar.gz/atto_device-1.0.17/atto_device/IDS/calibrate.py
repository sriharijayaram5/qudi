class Calibrate:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.ids.calibrate"

    def startCalibration(self):
        # type: () -> ()
        """
        Starts calibration system state.
        """
        
        response = self.device.request(self.interface_name + ".startCalibration")
        self.device.handleError(response)
        return                 

    def updateCalibration(self):
        # type: () -> ()
        """
        Updates linearized ramps with current ramp table.
        """
        
        response = self.device.request(self.interface_name + ".updateCalibration")
        self.device.handleError(response)
        return                 

    def checkCalibration(self):
        # type: () -> ()
        """
        Checks linearized ramps with current ramp table.
        """
        
        response = self.device.request(self.interface_name + ".checkCalibration")
        self.device.handleError(response)
        return                 

