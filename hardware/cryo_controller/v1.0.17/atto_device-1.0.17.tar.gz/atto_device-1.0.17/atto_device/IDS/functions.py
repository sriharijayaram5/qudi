class Functions:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.ids.functions"

    def _getApiReferencePosition(self, axis):
        # type: (int) -> ()
        """
        Return reference position for specified axis.

        Parameters:
            axis: [1|2|3]
                    
        """
        
        response = self.device.request(self.interface_name + "._getApiReferencePosition", [axis, ])
        self.device.handleError(response)
        return                 

    def getBiasTc(self, freq_hz):
        # type: (int) -> (int)
        """
        Get bias tc

        Parameters:
            freq_hz: Frequency in Hz
                    
        Returns:
            errNo: errNo
            value_biasTc: biasTc Bias tc
 within distance_absolute function
                    
        """
        
        response = self.device.request(self.interface_name + ".getBiasTc", [freq_hz, ])
        self.device.handleError(response)
        return response[1]                

