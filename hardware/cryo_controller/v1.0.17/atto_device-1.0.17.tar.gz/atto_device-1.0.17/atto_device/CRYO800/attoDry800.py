from . import ACS
from .breakVacuumValve import Breakvacuumvalve
from .access import Access
from .network import Network
from .pumpValve import Pumpvalve
from .sampleValve import Samplevalve
from .compressor import Compressor
from .exchange import Exchange
from .system import System
from .sample import Sample
from .system_service import System_service
from .tboard import Tboard
from .action import Action
from .about import About
from .main import Main
from .pressures import Pressures
from .update import Update
from .turboPump import Turbopump
from .membranePump import Membranepump


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.breakVacuumValve = Breakvacuumvalve(self)
        self.access = Access(self)
        self.network = Network(self)
        self.pumpValve = Pumpvalve(self)
        self.sampleValve = Samplevalve(self)
        self.compressor = Compressor(self)
        self.exchange = Exchange(self)
        self.system = System(self)
        self.sample = Sample(self)
        self.system_service = System_service(self)
        self.tboard = Tboard(self)
        self.action = Action(self)
        self.about = About(self)
        self.main = Main(self)
        self.pressures = Pressures(self)
        self.update = Update(self)
        self.turboPump = Turbopump(self)
        self.membranePump = Membranepump(self)
        
        

def discover():
    return Device.discover("attodry800")
